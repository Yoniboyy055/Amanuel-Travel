import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import styles from '../styles/AboutPage.module.css';

/**
 * About page
 *
 * Provides information about Amanuel Travel including its mission,
 * vision and unique selling points. This page is intentionally
 * content‑rich to help visitors understand the values behind the
 * business.
 */
export default function About() {
  return (
    <>
      <Head>
        <title>About Us – Amanuel Travel</title>
        <meta name="description" content="Learn more about Amanuel Travel, our mission to connect the Eritrean diaspora to home, and why travellers trust us." />
      </Head>
      <Header />
      <main className={styles.main}>
        <div className="container">
          <h1 className={styles.pageTitle}>About Amanuel Travel</h1>
          <p className={styles.lead}>
            Amanuel Travel was founded with a simple mission: to connect the Eritrean diaspora
            and curious travellers with the beauty, culture and people of Eritrea. We believe that
            travel should be personal, accessible and filled with authentic experiences.
          </p>
          <section className={styles.section}> 
            <h2>Our Story</h2>
            <p>
              What began as a small flight booking service in Toronto has grown into a full‑service
              agency offering flights, custom tour packages, hotel bookings and ground transport.
              Drawing on our local knowledge and deep community ties, we craft journeys that feel
              like coming home – even if it’s your first visit.
            </p>
            <p>
              We’re proud to serve families returning for weddings and holidays, adventurers seeking
              the unspoiled beauty of the Red Sea, and anyone longing to experience Eritrea’s
              unique blend of history and hospitality.
            </p>
          </section>
          <section className={styles.section}> 
            <h2>Why Choose Us?</h2>
            <ul className={styles.list}>
              <li>
                <strong>Diaspora connection specialist:</strong> we understand the unique needs of
                Eritreans living abroad and offer flexible options for family visits and group travel.
              </li>
              <li>
                <strong>Local expertise, real guidance:</strong> our itineraries are designed with
                on‑the‑ground insight so you experience the real Eritrea safely and comfortably.
              </li>
              <li>
                <strong>Personal touch & fast replies:</strong> our team responds quickly via
                WhatsApp and email, treating every traveller like family – not just a booking number.
              </li>
            </ul>
          </section>
          <section className={styles.section}> 
            <h2>Our Promise</h2>
            <p>
              We promise to provide transparent pricing, honest advice and unwavering support
              from the moment you contact us until you return home. Your journey matters to us
              because we know every trip holds a story – a reunion, an adventure, a dream fulfilled.
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}