import '../styles/globals.css';
import Head from 'next/head';

/**
 * Custom App component
 *
 * This component wraps every page in the application. It's a good place
 * to include global CSS imports and metadata that should be present on
 * every page, like fonts and viewport settings.
 */
export default function MyApp({ Component, pageProps }) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Amanuel Travel</title>
        {/* Preconnect to Google's font servers for faster loading */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* Load Poppins and Open Sans fonts */}
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&family=Open+Sans:wght@300;400;600&display=swap"
          rel="stylesheet"
        />
      </Head>
      <Component {...pageProps} />
    </>
  );
}