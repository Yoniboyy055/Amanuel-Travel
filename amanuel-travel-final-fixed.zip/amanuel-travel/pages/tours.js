import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import styles from '../styles/ToursPage.module.css';

/**
 * Tours page
 *
 * Provides an overview of the different tour packages available through
 * Amanuel Travel. Each tour is presented with an image, a name and a
 * short description. In a real application these would likely be
 * fetched from an API or CMS.
 */
export default function Tours() {
  const tours = [
    {
      slug: 'city-tour',
      image: '/images/andy-bridge-5h2FzGiSV64-unsplash.jpg',
      title: 'Asmara & Keren City Tour',
      description:
        'Discover the modernist architecture of Asmara, stroll through its lively markets and venture north to Keren to experience authentic Eritrean culture.'
    },
    {
      slug: 'island-adventure',
      image: '/images/heidi-bruce-LJIjXgutX4g-unsplash.jpg',
      title: 'Dahlak Islands Adventure',
      description:
        'Sail the azure waters of the Red Sea to the pristine Dahlak Archipelago. Snorkel coral reefs, relax on untouched beaches and explore historic ruins.'
    },
    {
      slug: 'highlands-trek',
      image: '/images/samuel-quek-pdffODhVQAU-unsplash.jpg',
      title: 'Highlands Trekking',
      description:
        'Embark on a trekking journey through Eritrea’s highlands. Enjoy panoramic mountain vistas, traditional villages and breathtaking sunsets.'
    }
  ];
  return (
    <>
      <Head>
        <title>Tours – Amanuel Travel</title>
        <meta name="description" content="Explore our curated tour packages including city heritage tours, island adventures and highland treks." />
      </Head>
      <Header />
      <main className={styles.main}>
        <div className="container">
          <h1 className={styles.pageTitle}>Our Tours</h1>
          <p className={styles.intro}>
            Whether you’re reconnecting with family or discovering Eritrea for the first time, our tours are crafted to deliver authentic and memorable experiences.
          </p>
          <div className={styles.grid}>
            {tours.map((tour) => (
              <div key={tour.slug} className={styles.card}>
                <div className={styles.imageWrapper}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={tour.image} alt={tour.title} className={styles.image} />
                </div>
                <h3 className={styles.cardTitle}>{tour.title}</h3>
                <p className={styles.cardDesc}>{tour.description}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}