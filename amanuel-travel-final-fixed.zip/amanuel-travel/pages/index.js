import Head from 'next/head';
import Header from '../components/Header';
import HeroSection from '../components/HeroSection';
import ServicesSection from '../components/ServicesSection';
import TestimonialsSection from '../components/TestimonialsSection';
import ContactForm from '../components/ContactForm';
import Footer from '../components/Footer';

/**
 * Homepage
 *
 * The main landing page pulls together the hero banner, service
 * highlights, client testimonials and a short contact form. Each
 * section is broken out into its own component for clarity.
 */
export default function Home() {
  return (
    <>
      <Head>
        <meta name="description" content="Amanuel Travel connects Eritrea with the world. Book flights, tours, hotels and transfers effortlessly." />
      </Head>
      <Header />
      <HeroSection />
      <ServicesSection />
      <TestimonialsSection />
      <section className="section">
        <div className="container">
          <h2 style={{ textAlign: 'center', color: 'var(--color-primary)', fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>
            Get in Touch
          </h2>
          <ContactForm />
        </div>
      </section>
      <Footer />
    </>
  );
}