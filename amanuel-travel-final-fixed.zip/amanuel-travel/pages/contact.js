import Head from 'next/head';
import Header from '../components/Header';
import Footer from '../components/Footer';
import ContactForm from '../components/ContactForm';
import styles from '../styles/ContactPage.module.css';

/**
 * Contact page
 *
 * Presents the enquiry form prominently and provides additional
 * information about how to get in touch. This page is separate from
 * the home page form so visitors can find it easily from the navigation.
 */
export default function Contact() {
  return (
    <>
      <Head>
        <title>Contact Us – Amanuel Travel</title>
        <meta name="description" content="Get in touch with Amanuel Travel to book flights, tours, hotels and transfers. We're here to help." />
      </Head>
      <Header />
      <main className={styles.main}>
        <div className="container">
          <h1 className={styles.pageTitle}>Contact Us</h1>
          <p className={styles.lead}>
            Ready to start planning your trip? Fill out the form below and our team will respond
            quickly. You can also reach us via WhatsApp or email any time.
          </p>
          <ContactForm />
          <div className={styles.details}>
            <h2>Other ways to reach us</h2>
            <p>
              <strong>WhatsApp:</strong> <a href="https://wa.me/">Chat on WhatsApp</a>
            </p>
            <p>
              <strong>Email:</strong> <a href="mailto:info@amanueltravel.com">info@amanueltravel.com</a>
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}