import styles from './ServicesSection.module.css';

/**
 * Services section component.
 *
 * Displays the core offerings of the travel agency. Each service is
 * represented by an emoji icon (for simplicity), a title and a short
 * description. The grid is responsive: cards stack on smaller screens.
 */
export default function ServicesSection() {
  const services = [
    {
      icon: '✈️',
      title: 'Flights',
      description:
        'Book affordable international and regional flights connecting Eritrea to the rest of the world.'
    },
    {
      icon: '🏞️',
      title: 'Tours',
      description:
        'Explore Eritrea with curated city walks, island adventures and highland treks tailored to you.'
    },
    {
      icon: '🏨',
      title: 'Hotels',
      description:
        'Enjoy comfortable stays with our partner hotels across Asmara, Massawa, Keren and beyond.'
    },
    {
      icon: '🚐',
      title: 'Transfers',
      description:
        'Relax with airport pickups, private drivers and reliable ground transportation services.'
    }
  ];
  return (
    <section className={`section ${styles.servicesSection}`}> 
      <div className="container">
        <h2 className={styles.heading}>Our Services</h2>
        <div className={styles.grid}>
          {services.map((service) => (
            <div key={service.title} className={styles.card}>
              <div className={styles.icon}>{service.icon}</div>
              <h3>{service.title}</h3>
              <p>{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}