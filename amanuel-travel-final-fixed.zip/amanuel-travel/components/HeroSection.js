import styles from './HeroSection.module.css';

/**
 * Hero section component.
 *
 * Displays a full-width background image with a dark overlay, a
 * prominent headline, a supporting subheading and a call‑to‑action
 * button. This is the first thing visitors see when they land on the
 * homepage.
 */
export default function HeroSection() {
  return (
    <section className={styles.hero}>
      <div className={styles.overlay}>
        <h1 className={styles.title}>Connecting Eritrea with the World</h1>
        <p className={styles.subtitle}>
          Affordable flights, tailored packages & unforgettable tours.
        </p>
        <a href="/contact" className={styles.cta}>Request a Quote</a>
      </div>
    </section>
  );
}