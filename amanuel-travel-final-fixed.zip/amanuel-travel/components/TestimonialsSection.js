import styles from './TestimonialsSection.module.css';

/**
 * Testimonials section component.
 *
 * Real quotes build trust. Here we include a few fictional but
 * representative testimonials to show what customers love about
 * Amanuel Travel. In a real site you would fetch these from a CMS or
 * database.
 */
export default function TestimonialsSection() {
  const testimonials = [
    {
      name: 'Mariam T.',
      location: 'Toronto, Canada',
      quote:
        'Booking my family’s flight home was so easy with Amanuel Travel. They answered all my questions on WhatsApp and found us a great price!'
    },
    {
      name: 'Kaleab G.',
      location: 'London, UK',
      quote:
        'The Asmara heritage tour was incredible. Our guide knew every story behind the architecture and the coffee ceremony was unforgettable.'
    },
    {
      name: 'Saba A.',
      location: 'Seattle, USA',
      quote:
        'From airport pickup to hotel and tours, everything was arranged perfectly. I felt looked after every step of the way.'
    }
  ];
  return (
    <section className={`section ${styles.testimonialsSection}`}> 
      <div className="container">
        <h2 className={styles.heading}>What Our Clients Say</h2>
        <div className={styles.grid}>
          {testimonials.map((t) => (
            <div key={t.name} className={styles.card}>
              <p className={styles.quote}>“{t.quote}”</p>
              <p className={styles.author}>
                – {t.name}, <span className={styles.location}>{t.location}</span>
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}