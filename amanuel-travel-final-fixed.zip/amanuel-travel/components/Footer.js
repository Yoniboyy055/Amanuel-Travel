import Link from 'next/link';
import styles from './Footer.module.css';

/**
 * Site footer component.
 *
 * Contains navigation links repeated for convenience as well as quick
 * contact methods. At the bottom a copyright notice is displayed.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div className={styles.links}>
          <Link href="/">Home</Link>
          <Link href="/tours">Tours</Link>
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
        </div>
        <div className={styles.social}>
          {/* Using simple text for contact links; these could be replaced with icons */}
          <a href="https://wa.me/" target="_blank" rel="noopener noreferrer">
            WhatsApp
          </a>
          <a href="mailto:info@amanueltravel.com">Gmail</a>
        </div>
      </div>
      <p className={styles.copy}>&copy; {year} Amanuel Travel. All rights reserved.</p>
    </footer>
  );
}