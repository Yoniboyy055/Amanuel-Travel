import Link from 'next/link';
import styles from './Header.module.css';

/**
 * Site-wide header component.
 *
 * The header contains the brand name and a navigation bar. It stays
 * anchored to the top of the viewport and collapses gracefully on
 * smaller screens.
 */
export default function Header() {
  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.logo}>
          Amanuel&nbsp;Travel
        </Link>
        <nav className={styles.nav}>
          <Link href="/">Home</Link>
          <Link href="/tours">Tours</Link>
          <Link href="/about">About</Link>
          <Link href="/contact">Contact</Link>
        </nav>
      </div>
    </header>
  );
}