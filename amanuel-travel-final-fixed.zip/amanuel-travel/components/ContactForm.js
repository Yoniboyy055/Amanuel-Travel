import { useState } from 'react';
import styles from './ContactForm.module.css';

/**
 * Contact form component.
 *
 * Collects the visitor's basic details and travel enquiry. When the
 * form is submitted we construct a `mailto:` link to open the user's
 * default email client prepopulated with their message. In a real
 * application you might instead send this data to a server or CRM.
 */
export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    itinerary: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Construct a mailto link with subject and body
    const subject = encodeURIComponent('Travel enquiry from ' + formData.name);
    const body = encodeURIComponent(
      `Name: ${formData.name}\nEmail: ${formData.email}\nPhone: ${formData.phone}\nFrom/To: ${formData.itinerary}\n\n${formData.message}`
    );
    const mailtoLink = `mailto:info@amanueltravel.com?subject=${subject}&body=${body}`;
    window.location.href = mailtoLink;
  };

  return (
    <form className={styles.form} onSubmit={handleSubmit}>
      <div className={styles.row}>
        <div className={styles.field}> 
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </div>
        <div className={styles.field}> 
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
      </div>
      <div className={styles.row}>
        <div className={styles.field}> 
          <label htmlFor="phone">Phone</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
        </div>
        <div className={styles.field}> 
          <label htmlFor="itinerary">From / To</label>
          <input
            type="text"
            id="itinerary"
            name="itinerary"
            value={formData.itinerary}
            onChange={handleChange}
            placeholder="e.g. Toronto → Asmara"
          />
        </div>
      </div>
      <div className={styles.fieldFull}> 
        <label htmlFor="message">Notes / Message</label>
        <textarea
          id="message"
          name="message"
          rows={4}
          value={formData.message}
          onChange={handleChange}
        />
      </div>
      <button type="submit" className={styles.submit}>Request Quote</button>
    </form>
  );
}