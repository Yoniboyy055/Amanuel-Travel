// Next.js configuration
// We leave this mostly default. If you decide to enable image domains
// or other advanced features later on, this is where you'd do it.
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true
};

module.exports = nextConfig;
